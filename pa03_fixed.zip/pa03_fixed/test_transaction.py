'''
Written by @Ijeoma Igbogu
Version 1.0 - @Jeremy Huey added a fix for the non-functional test_sum_by_day()
We decided to not test the other sum by as they are non-functional.
'''

## test_with_unittest.py
import unittest
import sqlite3
import transaction

''' create a table to store the Brandeis course data'''

con = sqlite3.connect('l.db')
cur = con.cursor()

cur.execute("DROP TABLE IF EXISTS transactions")
tra = transaction.Transaction("l.db")

cur.execute("SELECT * FROM transactions")
print(cur.fetchone())
con.close()

tra.modify_category(1, "retail")
x = tra.show_transactions()
print(x)





# creating interval objects

#i  = {'item_num': t[0], 'amount': t[1], 'category text': t[2], 'date': t[3], 'desc': t[4]}

# #(item_num,amount,category,date,description)
t = {"amount":23, "category":"food","day":5, "month": 12, "year":2023,"desc":"grocceries"}
t1= {"amount":500, "category":"travel", "day":31, "month": 7, "year":2023,"desc":"hotel"}
t2= {"amount":6700, "category":"rent", "day":16, "month": 3, "year":2023,"desc":"mortgage"}
t3= {"amount":100, "category":"food", "day":16, "month": 3, "year":2023,"desc":"mortgage"}


x = tra.show_transactions()
print(x)

#testing the constructor
def test_addTransaction():
    """
    Testing the addTransaction
    :return: boolean
    """

    x = tra.add_transaction(t)
    y= tra.add_transaction(t1)
    z = tra.add_transaction(t2)
    a = tra.add_transaction(t3)

    con = sqlite3.connect('l.db')
    cur = con.cursor()
    cur.execute("SELECT * FROM transactions where amount=23")
    x= cur.fetchone()
    assert x == (23, 'food', 5, 12, 2023, 'grocceries')
    cur.execute("SELECT * FROM transactions where amount=500")
    y = cur.fetchone()
    assert y == (500, 'travel', 31, 7, 2023, 'hotel')
    cur.execute("SELECT * FROM transactions where amount=6700")
    z = cur.fetchone()
    assert z == (6700, 'rent', 16, 3, 2023, 'mortgage')
    con.close()


def test_showTransactions():
    x = tra.show_transactions()
    print(x)
    assert x[0] == {'amount': 23,
                         'category text': 'food',
                         'day': 5,
                         'desc': 'grocceries',
                         'item_num': 1,
                        'month': 12,
                        'year': 2023}

    assert x[1] == {'amount': 500,
                    'category text': 'travel',
                    'day': 31,
                    'desc': 'hotel','item_num': 2,
                    'month': 7,
                    'year': 2023}

#index out of bound error
def test_sum_by_day():
    x = tra.sum_by_day(16)
    assert x[0][1]== 6800
    # changed this to x == None as we have a warning instead here print, so None is return.

def test_sum_by_month():
    x = tra.sum_by_month(3)
    assert x[0][1] == 6800

def test_sum_by_year():
    x = tra.sum_by_year(2023)
    print(x)
    assert x[0][1]== 7323




def test_sum_by_catergory():
    con = sqlite3.connect('l.db')
    cur = con.cursor()
    cur.execute("SELECT * FROM transactions where amount=23")
    z = tra.show_transactions()

    y = cur.fetchone()
    x = tra.sum_by_category("food")
    assert x[0][1]== 123
    con.close()

def test_modifyCategory():
  # t = {"amount":23, "category":"food","day":5, "month": 12, "year":2023,"desc":"grocceries"}

    tra.modify_category(1, "retail")
    x = tra.show_transactions()
    print(x)


    assert x[0] ==   {"item_num": 1,
                      'amount': 23,
                     'category text': 'retail',
                     'day': 5,
                     'desc': 'grocceries',
                     'item_num': 1,
                     'month': 12,
                     'year': 2023}

def test_delete_transaction():
    x = tra.delete_transaction(row_id=0)
    y = tra.show_transactions()
    unittest.assertFalsex=(x, y)
